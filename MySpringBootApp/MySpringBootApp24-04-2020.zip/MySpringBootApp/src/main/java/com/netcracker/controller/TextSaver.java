package com.netcracker.controller;

import com.netcracker.model.User;
import java.io.FileWriter;
import java.io.IOException;

public class TextSaver {
    public static void saveText(User user){
        try(FileWriter writer = new FileWriter("user.txt", false))
        {
            writer.write("");
            writer.append(user.toString());
            writer.flush();
        }
        catch(IOException ex){

            System.out.println(ex.getMessage());
        }
    }
}
