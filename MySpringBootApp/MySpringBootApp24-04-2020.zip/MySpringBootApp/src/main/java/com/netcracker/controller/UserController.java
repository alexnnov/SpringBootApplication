package com.netcracker.controller;

import com.netcracker.model.User;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import java.io.*;

@Controller
public class UserController {

    @GetMapping("/user")
    public String userForm(Model model){
        model.addAttribute("user", new User());
        return "user";
    }
    @PostMapping("/user")
    public String userSubmit(@ModelAttribute User user){
        if(user.getAge()<0) user.setAge(0);
        if(user.getId()<0) user.setId(0);
        TextSaver.saveText(user);
        return "userresult";
    }
    @PostMapping("/userresult")
    public String userResultSearch(String name){
        return "userresult";
    }

    @RequestMapping(value="/",method=RequestMethod.GET)
    public String getUserPage(Model model){
        return "user";
    }
}

